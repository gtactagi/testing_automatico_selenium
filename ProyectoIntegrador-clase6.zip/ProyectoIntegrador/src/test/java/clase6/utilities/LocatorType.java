package clase6.utilities;

public enum LocatorType {
    ID, NAME, CLASSNAME, XPATH

}
